'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://api.an9elkiss.cn:9001"'
}
